1:"$Sreact.fragment"
2:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/3d060d449bada4c1.js"],"ViewportBoundary"]
3:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/3d060d449bada4c1.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
5:I[27201,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/3d060d449bada4c1.js"],"IconMark"]
0:{"buildId":"YIju2R5HpxnRj6NPV4zlA","rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"NewEmage Content Auditor"}],["$","meta","1",{"name":"description","content":"Auditoría de contenido con IA y datos reales"}],["$","link","2",{"rel":"icon","href":"/favicon.ico?favicon.0b3bf435.ico","sizes":"256x256","type":"image/x-icon"}],["$","$L5","3",{}]]}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"loading":null,"isPartial":false}

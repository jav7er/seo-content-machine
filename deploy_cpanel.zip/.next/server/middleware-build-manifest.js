globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/061e7623f37bda0d.js",
    "static/chunks/82abf2d65f5428ae.js",
    "static/chunks/51d5f617a9f97cde.js",
    "static/chunks/821e78bdec6b9aa7.js",
    "static/chunks/turbopack-4e54ddff2da05967.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];